package jkyeiasare1;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CourseDBManager_STUDENT_Test {

	private CourseDBManagerInterface dataMgr = new CourseDBManager();
	
	@BeforeEach
	void setUp() throws Exception {
		dataMgr = new CourseDBManager();
	}

	@AfterEach
	void tearDown() throws Exception {
		dataMgr = null;
	}

	@Test
	void addtest() {
		try {
			dataMgr.add("JeffClass",20000,2,"JK120","Jeff Kyei");
		}
		catch(Exception e) {
			fail("This should not have caused an Exception");
		}
		
		for(CourseDBStructure s : dataMgr.getStructure()) {
			
		}
		
	}
	
	@Test
	void showAlltest() {
		dataMgr.add("CMSC202",30504,4,"SC450","Joey Bag-O-Donuts");
		dataMgr.add("CMSC205",30503,4,"SC450","Jill B. Who-Dunit");
		dataMgr.add("CMSC206",30559,4,"SC450","BillyBob Jones");
		ArrayList<String> list = dataMgr.showAll();
		assertEquals(list.get(0),"\nCourse:CMSC206 CRN:30559 Credits:4 Instructor:BillyBob Jones Room:SC450");
	 	assertEquals(list.get(1),"\nCourse:CMSC205 CRN:30503 Credits:4 Instructor:Jill B. Who-Dunit Room:SC450");
		assertEquals(list.get(2),"\nCourse:CMSC202 CRN:30504 Credits:4 Instructor:Joey Bag-O-Donuts Room:SC450")
		
	}
	
	@Test
	void getTest() {
		dataMgr.add("JeffClass",20000,2,"JK120","Jeff Kyei");
		assertEquals("JeffClass", dataMgr.get(20000).getID());
	
	}

}
