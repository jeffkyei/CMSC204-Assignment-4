package jkyeiasare1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface{
	CourseDBStructure structure;
	
	public CourseDBManager() {
		structure = new CourseDBStructure(50); //int n??
	}
	
//	String ID;
//	int CRN;
//	int numCredits;
//	String roomNum;
//	String instructor;
//	
//	public CourseDBManager(String ID, int CRN, int numCredits, String roomNum, String instructor) {
//		this.ID = ID;
//		this.CRN = CRN;
//		this.numCredits = numCredits;
//		this.roomNum = roomNum;
//		this.instructor = instructor;
//	}
	
	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		CourseDBElement e = new CourseDBElement(id, crn, credits, roomNum, instructor);
		structure.getLinkList().add(e);
		
	}

	public CourseDBStructure getStructure() {
		return structure;
	}
	
	public void setStructure(CourseDBStructure structure) {
		this.structure = structure;
	}

	@Override
	public CourseDBElement get(int crn) {
		boolean val = false;
		int correctIndex = 0;
		for(int i = 0; i < structure.getaList().length; i ++) { //for each linked list in the array
			for(int j = 0; j < structure.getLinkList().size(); j++) { //for each index in linkedlist
				
				int matchingCRN = structure.getLinkList().get(j).getCRN(); //at each index in the linkedlist get CRN
				
				if(crn == matchingCRN) { //if crns do match
					
					correctIndex = j; //get index
					val = true; //val is true
				}
			}
		}
		if(val = true) { //if val is true then return the CDE at linkedlist index correctIndex
			return structure.getLinkList().get(correctIndex);
		}else {
			return null;
		}
	}

	@Override
	public void readFile(File input) throws FileNotFoundException {
		try {
		      Scanner sc = new Scanner(input); //use scanner to actually read courses
		      System.out.println("file found");
		      
		      while (sc.hasNextLine()) { //while file not fully read
//		        String classes = sc.nextLine(); //classes is each line in file
//		        System.out.println(classes); //print out each line
		        
		        String id = sc.next();
		        System.out.println(id);
		        int crn = sc.nextInt();
		        System.out.println(crn);
		        int credits = sc.nextInt();
		        System.out.println(credits);
		        String room = sc.next();
		        System.out.println(room);
//		        //until sc.next == null
//		        String instructor = "";
//		        while(sc.hasNext()) {
//		        	System.out.println("HERE");
//		        	System.out.println(sc.next());
//			        instructor += sc.next() + " ";
//
//		        }
		        String instructor = sc.next();
		        System.out.println(instructor);
		
		        
		        CourseDBElement newCourse = new CourseDBElement(id, crn, credits, room, instructor);		 
		        structure.getLinkList().add(newCourse);
		        
		      }
		      sc.close(); //close scanner
		    } catch (FileNotFoundException e) { //just in case there is no file
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}
		

	@Override
	public ArrayList<String> showAll() {
//		ArrayList<String> info = new ArrayList<>();
//		
//		for(CourseDBElement e : structure.getLinkList()) {
//			info.add()
//		}
		
		return structure.showAll();
		
		
		/*
		 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
		 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
		 */
	}
	
}
