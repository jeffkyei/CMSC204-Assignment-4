package jkyeiasare1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.lang.Math;

public class CourseDBStructure implements CourseDBStructureInterface{

	double size; //size of hashtable
	final double loadFactor = 1.5;
	double prime; //prime
	int min; //minimum number the hashtable must be above
	
	LinkedList<CourseDBElement> linkList; //linkedlist
	//	ArrayList<LinkedList> aList; //arraylist
	LinkedList[] aList;

	
	//constructor 1 takes in int n to represent number of courses
	public CourseDBStructure(int n) {
		
//		min = (int) (n / loadFactor); //find 4K + 3 prime number greater than min
//		int i = 1;
//		int k = 0;
//		int primeNum = 4*k + 3;
//		
//		while (!((primeNum > min) && (isPrime(primeNum)))) { //while we are greater than min AND prime
//			k = k+1;
//			primeNum = primeNum;
//			
//			if(isPrime(primeNum)) { //if the number is above & min and prime size = prime break
//				size = primeNum;
//				break;
//			}
//			
//		}
		
//		aList = new ArrayList<LinkedList>(); //arraylist
		this.aList = new LinkedList[n];

//		for(int i = 0; i < n; i++) {
//			aList.add(null);
//		}
		
//		System.out.println("length: " + n);
		
		linkList = new LinkedList<CourseDBElement>(); //linkedlist
		
//		linkList
//		aList = new LinkedList[n];
	
	}
	
	public LinkedList<CourseDBElement> getLinkList() {
		return linkList;
	}

	public void setLinkList(LinkedList<CourseDBElement> linkList) {
		this.linkList = linkList;
	}

	public LinkedList[] getaList() {
		return aList;
	}

	public void setaList(LinkedList[] aList) {
		this.aList = aList;
	}

	//method to check if int is prime
	 public boolean isPrime(int num) {
		 if (num <= 1) {
			 return false;
		 }
		 for (int i = 2; i <= Math.sqrt(num); i++) {
			 if (num % i == 0) {
				 return false;
			 }
		 }
		 return true;
	 }

	//constructor 2 for testing
	public CourseDBStructure(String t, int size) {
		t = "testing";
		this.size = size;
		
	}
	

	//Add CDE to CDS linkedlist
	@Override
	public void add(CourseDBElement element) {
		for(CourseDBElement e : linkList) {
			if(e.compareTo(element) != 0) {
				//if element not already in linklist
				//add element
				
				int elementCRN = element.getCRN(); //get CRN of the element
				String crnString = Integer.toString(elementCRN); //turn CRN into String
				int hashInt = crnString.hashCode(); //get hashcode of element based on string
				
				if(aList[hashInt] == null) {
					LinkedList<CourseDBElement> newLink = new LinkedList<CourseDBElement>(); //create new linkedlist
					newLink.add(element); //add element as the first element
					
					aList[hashInt] = newLink; //add this new linkedlist to array at hashInt index
				}else {
					linkList.add(element);
				}
				
				
			}
		}
	}

	
	//Find CDE based off crn as key
	//either return CDE there or throw exception
	@Override
	public CourseDBElement get(int crn) throws IOException {
		boolean val = false;
		int correctIndex = 0;
		for(int i = 0; i < aList.length; i ++) { //for each linked list in the array
			for(int j = 0; j < linkList.size(); j++) { //for each index in linkedlist
				
				int matchingCRN = linkList.get(j).getCRN(); //at each index in the linkedlist get CRN
				
				if(crn == matchingCRN) { //if crns do match
					
					correctIndex = j; //get index
					val = true; //val is true
				}
			}
		}
		if(val = true) { //if val is true then return the CDE at linkedlist index correctIndex
			return linkList.get(correctIndex);
		}
		else {
			System.out.println("ERRORERROR");
			throw new IOException(" You attempting to retrieve a CDE that does not exist in the DB.");
		}
	}
		
	

	@Override
	public ArrayList<String> showAll() {
		ArrayList<String> stringList = new ArrayList<String>();
		
		for(int i = 0; i < aList.length; i ++) {
//			for(int j = 0; j < linkList.size(); j++) {
			for(int j = linkList.size()-1; j >= 0; j--) {
				String courseString = "\n" + linkList.get(j);
				stringList.add(courseString);
			}
		}
//		System.out.println(stringList);
		return stringList;
	}

	@Override
	public int getTableSize() {
		//for(int j = 0; j < size; j++) {
			//aList.add(j, linkList);
		//}
//		return aList.size();
		return aList.length;
	}
	

//	public static void main(String args[]) {
//		CourseDBElement cde1 = new CourseDBElement("CMSC100", 11111, 1, "Room # 1", "Teacher #1"); //coursedbelement
//		CourseDBElement cde2 = new CourseDBElement("CMSC200", 22222, 2, "Room # 2", "Nobody InParticular"); //coursedbelement
//		CourseDBElement cde3 = new CourseDBElement("CMSC300", 33333, 3, "Room # 3", "Nobody InParticular"); //coursedbelement
//		
//		LinkedList<CourseDBElement> list1 = new LinkedList<CourseDBElement>(); //create  generic linkedlist
//		LinkedList<CourseDBElement> list2 = new LinkedList<CourseDBElement>();
//		LinkedList<CourseDBElement> list3 = new LinkedList<CourseDBElement>();
//		
//		list1.add(cde1);
//		list2.add(cde2);
//		list3.add(cde3);
//		
//		
//		ArrayList<LinkedList> aList = new ArrayList<LinkedList>(); //create array of linkedlist
//		aList.add(list1); //index/slot/bucket 1 is linked list 1 and linked list 1 has cde1
//		aList.add(list2);
//		aList.add(list3);
//		
//	}
}
