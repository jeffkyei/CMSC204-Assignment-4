package jkyeiasare1;

public class CourseDBElement implements Comparable {

	String ID;
	int CRN;
	int numCredits;
	String roomNum;
	String instructor;
	
	public CourseDBElement(String ID, int CRN, int numCredits, String roomNum, String instructor) { //constructor
		this.ID = ID;
		this.CRN = CRN;
		this.numCredits = numCredits;
		this.roomNum = roomNum;
		this.instructor = instructor;

	}

	//getters & setters
	@Override
	public int compareTo(Object o) {
		int compare = ((CourseDBElement) o).getCRN();
		return this.getCRN() - compare;
	}
	
	@Override
	public String toString() {
		//Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
		return "Course:" + ID + " CRN:" + CRN + " Credits:" + numCredits + " Instructor:" + instructor + " Room:" + roomNum;
	}

	public String getID() {
		return ID;
	}

	public void setID(String courseID) {
		this.ID = courseID;
	}

	public int getCRN() {
		return CRN;
	}

	public void setCRN(int cRN) {
		CRN = cRN;
	}

	public int getNumCredits() {
		return numCredits;
	}

	public void setNumCredits(int numCredits) {
		this.numCredits = numCredits;
	}

	public String getRoomNum() {
		return roomNum;
	}

	public void setRoomNum(String roomNumber) {
		this.roomNum = roomNumber;
	}

	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

		
		
}
